import React from 'react';
import { ArrowRight } from 'lucide-react';

export default function Hero() {
  return (
    <div className="relative bg-gradient-to-r from-blue-600 to-blue-800 animate-gradient h-screen flex items-center">
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1677442136019-21780ecad995"
          alt="AI Background"
          className="w-full h-full object-cover opacity-20"
        />
      </div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h1 
          className="text-4xl md:text-6xl font-bold text-white mb-6 animate-typewriter"
          style={{ '--duration': '3000ms' } as React.CSSProperties}
        >
          Welcome to the AI Business Club
        </h1>
        <p className="text-xl md:text-2xl text-blue-100 mb-8 max-w-3xl mx-auto animate-float">
          Explore the exciting world of artificial intelligence and its practical applications in business.
          No prior experience needed – we'll teach you everything you need to know!
        </p>
        <a
          href="#join"
          className="inline-flex items-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-blue-600 bg-white hover-glow hover-slide"
        >
          Join the AI Business Club Today!
          <ArrowRight className="ml-2 h-5 w-5" />
        </a>
      </div>
    </div>
  );
}