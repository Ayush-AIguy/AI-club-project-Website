import React from 'react';
import { LucideIcon } from 'lucide-react';

interface ServiceCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  index: number;
}

export default function ServiceCard({ icon: Icon, title, description, index }: ServiceCardProps) {
  return (
    <div 
      className="p-8 rounded-lg bg-white shadow-lg hover-scale hover-glow"
      style={{ animationDelay: `${index * 200}ms` }}
    >
      <div className="mb-6 animate-float">
        <Icon className="h-12 w-12 text-blue-600" />
      </div>
      <h3 className="text-xl font-semibold mb-4">{title}</h3>
      <p className="text-gray-600 leading-relaxed">{description}</p>
    </div>
  );
}