import React from 'react';
import { Bot, Globe } from 'lucide-react';
import ServiceCard from './ServiceCard';

export default function Services() {
  const services = [
    {
      icon: Bot,
      title: "AI Customer Support Agents",
      description: "Design and implement intelligent virtual agents to handle customer queries efficiently. Our agents are tailored to your specific business needs, ensuring a seamless customer support experience."
    },
    {
      icon: Globe,
      title: "Website Creation",
      description: "Develop professional and user-friendly websites from scratch. Our team combines creativity with technology to deliver websites optimized for your goals, whether personal, professional, or business-oriented."
    }
  ];

  return (
    <section id="services" className="py-20 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-4 animate-float">Our Services</h2>
        <p className="text-lg text-gray-600 text-center mb-16 max-w-3xl mx-auto">
          We specialize in providing innovative, AI-powered solutions to empower businesses and individuals.
        </p>
        <div className="grid md:grid-cols-2 gap-8">
          {services.map((service, index) => (
            <ServiceCard
              key={index}
              index={index}
              icon={service.icon}
              title={service.title}
              description={service.description}
            />
          ))}
        </div>
      </div>
    </section>
  );
}