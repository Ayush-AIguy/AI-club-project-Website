import React from 'react';

export default function Leadership() {
  const leaders = [
    {
      name: "Ayush Bose",
      role: "President"
    },
    {
      name: "Puneeth Kolla",
      role: "Vice President"
    },
    {
      name: "Tejus Golakoti",
      role: "Secretary"
    },
    {
      name: "Anish Aakaram",
      role: "Treasurer"
    }
  ];

  return (
    <section id="leadership" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-16">Leadership Team</h2>
        <div className="grid md:grid-cols-4 gap-8">
          {leaders.map((leader, index) => (
            <div key={index} className="text-center p-6 rounded-lg hover-glow hover-scale">
              <h3 className="text-xl font-semibold">{leader.name}</h3>
              <p className="text-gray-600">{leader.role}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}