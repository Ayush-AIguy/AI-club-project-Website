// Animation utility for text typing effect
export const typewriterAnimation = (text: string, duration: number = 3000) => {
  return {
    className: "animate-typewriter",
    style: {
      '--text-content': `'${text}'`,
      '--duration': `${duration}ms`,
    } as React.CSSProperties,
  };
};